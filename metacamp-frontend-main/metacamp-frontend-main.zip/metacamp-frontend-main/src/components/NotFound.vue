<template>
  <div style="text-align: center; padding-top: 20px">
    <h1 class="text-60">404</h1>
    <p class="text-36 subheading mb-3">Page not found!</p>
    <p class="mb-5 text-muted text-18">Sorry! The page you were looking for doesn't exist.</p>
    <a class="btn btn-lg btn-primary btn-rounded" href="/">Go back to home</a>
  </div>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped></style>
