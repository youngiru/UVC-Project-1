<template>
  <div>
    <h1>Home</h1>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam doloremque fugit voluptatum illo nemo nihil
      pariatur perferendis ad atque similique officiis, sapiente accusantium eos odit aspernatur deserunt. Blanditiis,
      aut molestias.
    </p>
  </div>
</template>

<script>
export default {}
</script>
